﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(GUIText))]

/*
 * The ScoreGUI class represents the Scoreboard that runs in the
 * upper right portion of the screen.  It tells us our score.
 * It is independent of the other GUI elements for
 * placement purposes. --Jamie O
 * */

public class ScoreGUI : MonoBehaviour 
{
	GameData worldPointer;

	// Use this for initialization
	void Start ()
	{
		//Get a pointer to the Game Data, where the score is held.
		worldPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
	
	}
	
	// Update is called once per frame
	void Update ()
	{

		//print in this corner:  "Score: XXXX"
		this.guiText.text = "Score:  " + worldPointer.getScore();
	
	}
}
