﻿using UnityEngine;
using System.Collections;


//Global data can be stored in this class.
public class GameData : MonoBehaviour
{
	public enum DrunkennessTier {TIER_0, TIER_1, TIER_2, TIER_3, TIER_4, TIER_5,
		TIER_6, TIER_7, TIER_8};
	
	private int score;
	private double gameTime;
	
	
	// Use this for initialization
	void Start ()
	{
		resetScore();
		gameTime = 300;
	}
	
	// Update is called once per frame
	void Update ()
	{
		gameTime -= Time.deltaTime;
		if (isTimeOut())
		{
			Application.LoadLevel(1);
		}
	}
	
	//Functions for manipulating the game clock
	public double getTimer() {return gameTime;}
	
	//see if the player is out of time.
	public bool isTimeOut()
	{
		if (gameTime <= 0)
			return true;
		return false;
	}
	
	
	//Functions for manipulating the score
	public int getScore() {return score;}
	public void resetScore() {score = 0;}
	public void raiseScore(int raise) { score += raise;}
}
