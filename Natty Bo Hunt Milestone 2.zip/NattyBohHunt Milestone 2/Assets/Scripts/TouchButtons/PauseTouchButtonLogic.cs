using UnityEngine;
using System.Collections;


[RequireComponent(typeof(GUITexture))]
//Code based on examples in the Unity documentation.
public class PauseTouchButtonLogic : MonoBehaviour
{

	
	void Update()
	{

		GUITexture thisHitBox = (GUITexture)gameObject.GetComponent(typeof(GUITexture));
		
		GameData gameDataPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
				
		foreach (Touch touch in Input.touches)
		{
			if (touch.phase == TouchPhase.Began)
			{
				if(thisHitBox.HitTest(touch.position))
				{
					gameDataPointer.togglePause();
				}				
			}
			

		}
	}
}
