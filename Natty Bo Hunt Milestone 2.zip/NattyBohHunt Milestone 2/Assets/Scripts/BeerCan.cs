﻿using UnityEngine;
using System.Collections;

public class BeerCan : MonoBehaviour
{
	private const int POINTS_VALUE = 100;

	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}
	
	//OnTriggerEnter checks to see if the beer can has been touched.
	//We really only care if Boh Boy touches the beer, so we'll start with a check
	//for that.  Then we'll see if he's got what it takes to pick it up.
	//We'll favor fast returns in our logic and avoid nested if statements.
	void OnTriggerEnter(Collider other)
	{
		//If something other than Boh Boy touches the can, return.
		if (other.gameObject.name.Equals("NattyBohBoy"))
		{
		}
		else
		{
			return;
		}
		
		//Now that we are guaranteed a player object, make a pointer to it.
		Player playerPointer = (Player)other.gameObject.GetComponent(typeof(Player));
		
		//Collect the beer if we have room for it.
		if (playerPointer.getBeerCount() < 5)
		{
		playerPointer.addBeer();
		Destroy (this.gameObject);
		
		//Make a pointer to the world data, and raise our score!
		GameData worldPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
		worldPointer.raiseScore(POINTS_VALUE);
		}
	}
}
