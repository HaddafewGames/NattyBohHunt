using UnityEngine;
using System.Collections;

/*This script is a heavily modified version of the one published by Rocket5 Studios as part of
 * their "Make a 2D Game in Unity3d Using Only Free Tools" series.  We have completely rewritten
 * the controls, heavily modified how animations are selected, and are implementing jumping and other
 * motions not used in the original.  Many sections of the code refer to components will will not be using;
 * these will be cleaned up in subsequent edits.
 * 
 * --Jamie O
 *
 **/


// This script is part of the tutorial series "Making a 2D game with Unity3D using only free tools"
// http://www.rocket5studios.com/tutorials/make-a-2d-game-in-unity3d-using-only-free-tools-part-1

[RequireComponent(typeof (CharacterController))]

public class Player : MonoBehaviour {
	
	
	//TODO:  Check out these constantcs and make sure that the ratios are perfect.  Jump
	//speed is very, very hard to nail down so that the height vs. fall speed is good.
	
	//Movement constants
	private const float MOVE_SPEED = 8.0f;
	private const float GRAVITY = (MOVE_SPEED) /*(2.0f/3.0f) */;
	private const float JUMP_SPEED = MOVE_SPEED * (50.0f/100.0f); 	//Jump speed seems to scale best
																	//as a fraction of move speed.
	
	//The movement vector is very important as it will tell the CharacterController where to move.
	private Vector3 movement;
	private CharacterController controller;
	
	private bool canJump;
	private bool canDoubleJump;
			
	/*These control animating state*/
	public OTAnimatingSprite mySprite;
	public xa.anim currentAnim;
	
	
	/*We define a way to determine our facing in easily-understood language*/
	public enum Facing {LEFT, RIGHT};
	public Facing ourFacing;
		
	void Awake() 
	{
		movement = new Vector3(0f,0f,0f);
		controller = (CharacterController) GetComponent(typeof(CharacterController));
		
	}
	
	void Start()
    {
		xa.alive = true;
		mySprite = GetComponent<OTAnimatingSprite>();
		ourFacing = Facing.RIGHT;						//Games just tend to start with the hero facing right.
														//This is a convention and has no real bearing in gameplay.
    }
	

	public void FixedUpdate()
	{
		//physics stuff; nothing needed yet.
		
	}
	
	public void Update ()
	{	
		if (controller.isGrounded) canJump = true;
		if (controller.isGrounded) canDoubleJump = true;
		
		movement = checkInput(movement);	//Update the movement vector by looking for input from the keyboard.
		updateMovement(movement);  			//Move Boh Boy according to the input vs. collision/physics.
	}
	
	
	//END OF UPDATE() -- TODO:  Chunk Update() into several methods for readability
	/////////////////////////////////////////////////////////////////////////////
	
	
	public Vector3 checkInput(Vector3 movement)
	{
		//I've re-written all of the keyboard controls from the original tutorial as they do not make for very smooth
		//playing and can cause some issues with jumping --Jamie O
		
		// keyboard input and results.
		
		//left and right controls:
		//////////////////////////////////////////////////////////////////////////////
		
		/*The pattern for these commands is as such: modify the movement vector,
		 * Change facing,
		 * Start the animation if it's not already playing,
		 * Flag the animation as playing.*/
		

		

		
		//Go Left
		if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) 
		{ 
			movement.x = -1;
			ourFacing = Facing.LEFT;

			if (currentAnim != xa.anim.WalkLeft)
					mySprite.Play("runLeft");
			currentAnim = xa.anim.WalkLeft;

		}
		
		//Go Right
		else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) 
		{
			movement.x = 1; 
			ourFacing = Facing.RIGHT;
			
			if (currentAnim != xa.anim.WalkRight)
				mySprite.Play("runRight");
			currentAnim = xa.anim.WalkRight;		
		}
		
		// If we're not moving either direction, set the x component of the vector to 0.0.
		else { movement.x = 0.0f;}
		
		/* STANDING ANIMATIONS:  Are we facing a direction, but not pressing the key
		//to move in that direction?  Then we display standing still!  Do not modify
		//movement, otherwise the logic is the same as above.*/
		
		//Standing Left
		if (ourFacing == Facing.LEFT)
		{
			if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandLeft)
					mySprite.Play("StandLeft");
				currentAnim = xa.anim.StandLeft;
			}
		}
		
		//Standing Right
		if (ourFacing == Facing.RIGHT)
		{
			if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandRight)
					mySprite.Play("StandRight");
				currentAnim = xa.anim.StandRight;
			}
		}
		

		/*
		 *JUMPING CONTROLS:
		 *Jumping has three states:  Jumping, falling, and on the ground.
		 *Pressing the jump key when you are on the ground creates vertical acceleration.
		 *Being in the air applies negative acceleration (gravity).
		 *Being on the ground negates negative acceleration.
		 */
		
		print (canJump);
	
		//If you have a jump available
		if ((Input.GetKeyDown(KeyCode.W) || Input.GetKeyUp(KeyCode.UpArrow)) && canJump)
		{
			movement.y = JUMP_SPEED;
			canJump = false;
		}
				
		if (controller.isGrounded)
		{
			movement.y = 0;
		}
		else
		{
			canJump = false;
			movement.y -= GRAVITY * Time.deltaTime;
		}
		
		/*else if (Input.GetKey (KeyCode.S))
		{ movement.y = -1.0f;}
		
		else {movement.y = 0.0f;}*/
		
		return movement;
	}
	
	/* updateMovement() takes the movement vector that has been augmented
	 * by the player input, and converts that into a vector that will move
	 * Boh Boy to his new location.  It does check for collisions!
	*/
	public void updateMovement(Vector3 movement)
	{
		movement = transform.TransformDirection(movement);
		movement *= MOVE_SPEED; //our movement rate.
		//movement.y -= GRAVITY;
		controller.Move(movement * Time.deltaTime);
	}
	
	
	//Clear the movment vector with this method.  Use this at the start of an update to avoid
	//old data contaminating any movement calculations.
	private void zeroMoveVector()
	{
		movement = Vector3.zero;
	
	}
	
	
}
