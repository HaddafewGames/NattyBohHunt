﻿using UnityEngine;
using System.Collections;

public class DownTouchButton : MonoBehaviour {

	// Use this for initialization
	void Start () {
		this.transform.Rotate(0,0,180);
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
