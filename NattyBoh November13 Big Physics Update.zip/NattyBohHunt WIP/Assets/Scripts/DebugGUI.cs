﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(GUIText))]

/*
 * The BeerGUI class represents the Scoreboard that runs in the
 * upper left portion of the screen.  It tells us our beer count and
 * our BAC levels.  It is independent of the other GUI elements for
 * placement purposes. --Jamie O
 * */

public class DebugGUI : MonoBehaviour 
{
	Player playerPointer;
	string BACtext;
	
	// Use this for initialization
	void Start ()
	{
		//Get a pointer to the player.
		playerPointer = (Player)GameObject.Find("NattyBohBoy").GetComponent(typeof(Player));
	
	}
	
	// Update is called once per frame
	void Update ()
	{
		//Print Debug text
		this.guiText.text = ("MomentumDirection: " + playerPointer.momentumDirection);
	
	}
}
