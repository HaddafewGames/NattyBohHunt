﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof (CharacterController))]

public class HipsterRA : MonoBehaviour
{

	//Movement constants
	private const float MOVE_SPEED = 8.0f;
	private const float GRAVITY = (MOVE_SPEED) /*(2.0f/3.0f) */;
	private const float JUMP_SPEED = MOVE_SPEED * (50.0f/100.0f); 	//Jump speed seems to scale best
																	//as a fraction of move speed.
	
	//The movement vector is very important as it will tell the CharacterController where to move.
	private Vector3 movement;
	private CharacterController controller;
	
	//Variabes used to manage jumping.
	private bool canJump;
			
	//These control animating state.  THESE ARE LEFT OVER FROM THE MAIN CHARACTER; DO NOT USE.*/
	public OTAnimatingSprite mySprite;
	public xa.anim currentAnim;
		
	//sound clips; we have none currently
	AudioSource[] clips;
		
	GameData gameDataPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
	
	//We define a way to determine our facing in easily-understood language*/
	public enum Facing {LEFT, RIGHT, NEITHER};
	public Facing ourFacing;
	public Facing currentFacing;
	
	
	void Awake() 
	{
		movement = new Vector3(0f,0f,0f);
		controller = (CharacterController) GetComponent(typeof(CharacterController));
		
	}
	
	void Start()
    {
		mySprite = GetComponent<OTAnimatingSprite>();
		ourFacing = Facing.LEFT;						//Enemes tend to start facing left
		currentFacing = Facing.NEITHER;
		
		//Load all of the sound clips into the clips container.
		int numberOfClips = GetComponents(typeof(AudioSource)).Length;
		clips = new AudioSource[numberOfClips];
		
		for (int i = 0; i < numberOfClips; i++)
		{
			clips[i]= (AudioSource)GetComponents(typeof(AudioSource))[i];
		}		
    }
	

	public void FixedUpdate()
	{
		//physics stuff; nothing needed yet.
		
	}
	
	public void Update ()
	{	
		if (controller.isGrounded) canJump = true;
	
		movement = checkMovementInput(movement);
		updateMovement(movement);  			//Move the enemy vs. collision/physics.
	}
	
	
	//Wandering enemies head left until they hit something, and then head right.
	//These enemies are subject to gravity.
	public Vector3 checkMovementInput(Vector3 movement)
	{
		
		if (ourFacing == Facing.LEFT)
		{
			//print ("Going left!");
			movement.x = -1;
			
			if (currentFacing != Facing.LEFT)
				mySprite.Play("WalkingLeft");
			currentFacing = Facing.LEFT;
			
			
		}
		if (ourFacing == Facing.RIGHT)
		{
			//print ("Going right!");
			movement.x = 1;
			
			if (currentFacing != Facing.RIGHT)
				mySprite.Play("WalkingRight");
			currentFacing = Facing.RIGHT;
		}
		
		if( (controller.collisionFlags & CollisionFlags.Sides) != 0)
		{
			toggleFacing();
			movement.x = 0;
		}

		movement.y -= GRAVITY * Time.deltaTime;
		return movement;
	}
	
	/* updateMovement() takes the movement vector that has been augmented
	 * by the player input, and converts that into a vector that will move
	 * Boh Boy to his new location.  It does check for collisions!
	*/
	public void updateMovement(Vector3 movement)
	{
		movement = transform.TransformDirection(movement);
		movement *= MOVE_SPEED; //our movement rate.
		controller.Move(movement * Time.deltaTime);
	}
	
	
	//This method is called if the enemy collides with a thing.  We want to use it to
	//see if we hit the Boh Boy, or if we hit a wall of some kind.
	void OnTriggerEnter(Collider other)
	{
		//If something other than Boh Boy touches the can, return.
		if (other.gameObject.name.Equals("NattyBohBoy"))
		{
		}
		else
		{
			return;
		}
		
		//Now that we are guaranteed a player object, make a pointer to it.
		Player playerPointer = (Player)other.gameObject.GetComponent(typeof(Player));
		playerPointer.playHurtSound();
		Destroy (this.gameObject);
	}
	
	//This switches the enemy's facing from left to right, or right to left.
	private void toggleFacing()
	{
		if (ourFacing == Facing.LEFT)
		{

			ourFacing = Facing.RIGHT;
		}
		else
		{
			ourFacing = Facing.LEFT;
		}
	}

}
