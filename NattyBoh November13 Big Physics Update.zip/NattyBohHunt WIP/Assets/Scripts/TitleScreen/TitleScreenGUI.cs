﻿using UnityEngine;
using System.Collections;

/*
 * TitleScreenGUI is the script for drawing the title screen; we use
 * proportions of the screen's height and width in order to place things
 * accurately on all screen sizes. --Jamie O*/

public class TitleScreenGUI : MonoBehaviour
{
	int HEIGHT = Screen.height;
	int WIDTH = Screen.width;
	const int STEP_VALUE = 30;


	void OnGUI()
	{
		int firstButtonW = Mathf.FloorToInt(WIDTH *.45f);		//Place the first button starting 45% of the width
		int firstButtonH = Mathf.FloorToInt(HEIGHT *.50f);		//Place the first button starting 50% of the height
		
		int titleW = Mathf.FloorToInt(WIDTH *.45f);				//Place the title starting 45% of the width
		int titleH = Mathf.FloorToInt(HEIGHT *.33f);			//Place the title starting 33% of the height
		
		
		GUI.Label(new Rect(titleW, titleH, 100, 100), "Natty Bo Hunt");
		
		if (GUI.Button(new Rect(firstButtonW, firstButtonH, 100,20), "Start Game"))
		{
			Application.LoadLevel(1);
		}
		
		if (GUI.Button(new Rect(firstButtonW,firstButtonH + STEP_VALUE,100,20), "How To Play"))
		{
			//This button currently does nothing.  Functionality is to be implemented at a later date.
		}
		
		if (GUI.Button(new Rect(firstButtonW,firstButtonH + 2*STEP_VALUE,100,20), "High Scores"))
		{
			//This button currently does nothing.  Functionality is to be implemented at a later date.
		}
		
		if (GUI.Button(new Rect(firstButtonW,firstButtonH + 3*STEP_VALUE,100,20), "Credits"))
		{
			//This button currently does nothing.  Functionality is to be implemented at a later date.
		}
		
		if (GUI.Button(new Rect(firstButtonW,firstButtonH + 4*STEP_VALUE, 100,20), "Quit Game"))
		{
			Application.Quit();
		}
		
		
	}
}
