using UnityEngine;
using System.Collections;

/*This script is a heavily modified version of the one published by Rocket5 Studios as part of
 * their "Make a 2D Game in Unity3d Using Only Free Tools" series.  We have completely rewritten
 * the controls, heavily modified how animations are selected, and are implementing jumping and other
 * motions not used in the original.  Many sections of the code refer to components will will not be using;
 * these will be cleaned up in subsequent edits.
 * 
 * --Jamie O
 *
 **/


[RequireComponent(typeof (CharacterController))]

public class Player : MonoBehaviour
{
	
	
	//TODO:  Check out these constants and make sure that the ratios are perfect.  Jump
	//speed is very, very hard to nail down so that the height vs. fall speed is good.
	
	//Movement constants
	private const float MOVE_SPEED = 8.0f;
	private const float GRAVITY = (MOVE_SPEED) /*(2.0f/3.0f) */;
	private const float JUMP_SPEED = MOVE_SPEED * (50.0f/100.0f); 	//Jump speed seems to scale best
																	//as a fraction of move speed.
		
	//MOMENTUM SYSTEM:  Have a current speed, and a target speed.
	/*private*/ public float currentSpeed;
	/*private*/ public float desiredSpeed;
	/*private*/ public float maxSpeed = 1.0f;
	/*private*/ public float acceleration;
	public float deceleration;
		
	//The movement vector is very important as it will tell the CharacterController where to move.
	private Vector3 movement;
	private CharacterController controller;
	
	//Variabes used to manage jumping.
	/*private*/ public bool canJump;
	/*private*/ public bool canDoubleJump;
	/*private*/ public bool canWallJump;
	/*private*/ public Facing momentumDirection; 	//needed to know which way we were going when we hit a wall.
	
	//Variables used to manage swimming.
	/*private*/ public bool isSwimming;
		
	//Variables used to handle the touchscreen interface.
	private bool touchScreenJump;
	private bool touchScreenLeft;
	private bool touchScreenRight;
	private bool touchScreenChug;
			
	//Variables for counting beer
	private GameData.DrunkennessTier tier;
	private int beerCount;
	private double BAC;
	private const double BEER_BAC_VALUE = 0.018;		//This value was taken from http://bloodalcoholcalculator.org/
														//as one light beer at its highest blood concentration.
	private bool drunkTierDifferent;
	
	//These control animating state*/
	public OTAnimatingSprite mySprite;
	public xa.anim currentAnim;
	
	
	//sound clips that originate from the Boh Boy:
	AudioSource[] clips;
	
	//This points to the game world.
	GameData gameDataPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
		
	
	//We define a way to determine our facing in easily-understood language*/
	public enum Facing {LEFT, RIGHT};
	public Facing ourFacing;
	
	
	void Awake() 
	{
		movement = new Vector3(0f,0f,0f);
		controller = (CharacterController) GetComponent(typeof(CharacterController));
		
		desiredSpeed = 0;
		currentSpeed = 0;
		maxSpeed = 1.2f;
		
		acceleration = 1.0f;
		deceleration = 3 * acceleration;
		
		canWallJump = false;
		
		initializeAlcohol();
		initalizeTSFlags();
		loadSounds();
		
		isSwimming = false;
	
	}
	
	void Start()
    {
		mySprite = (OTAnimatingSprite) GetComponentsInChildren(typeof(OTAnimatingSprite))[1];
		ourFacing = Facing.RIGHT;						//Games just tend to start with the hero facing right.
														//This is a convention and has no real bearing in gameplay.
    }
	
	void loadSounds()
	{
		int numberOfClips = GetComponents(typeof(AudioSource)).Length;
		clips = new AudioSource[numberOfClips];

		
		for (int i = 0; i < numberOfClips; i++)
		{
			clips[i]= (AudioSource)GetComponents(typeof(AudioSource))[i];
		}
	}
	
	void initializeAlcohol()
	{
		beerCount = 0;
		BAC = 0;
		drunkTierDifferent = false;
	}
	
	void initalizeTSFlags()
	{
		touchScreenJump = false;
		touchScreenLeft = false;
		touchScreenRight = false;
		touchScreenChug = false;		
	}
	
	

	public void FixedUpdate()
	{
		//physics stuff; nothing needed yet.
		
	}
	
	public void Update ()
	{	
		if (controller.isGrounded) canJump = true;
		if (controller.isGrounded) canDoubleJump = true;
		
		
		if (!isSwimming)
		{
			movement = checkMovementInput(movement);	//Update the movement vector by looking for input from the keyboard.
			updateXMomentum();
		}
		if (isSwimming)
		{
			movement = checkSwimInput(movement);
		}

		checkActionInput();
		updateMovement(movement);  			//Move Boh Boy according to the input vs. collision/physics.
		changeMaxSpeed();
		setMomentumFacing();				//See which way we're being pushed.
		
		//Things that must routinely toggle off are done here.
		canWallJump = false;
		isSwimming = false;
	}
	
	
	
	public Vector3 debugMovement()
	{
		return movement;
	}
	
	public void setMomentumFacing()
	{
		if(currentSpeed > 0)
			momentumDirection = Facing.RIGHT;
		if(currentSpeed < 0)
			momentumDirection = Facing.LEFT;
	}
	
	
	//Let's change the magnitude of the X component of the movement vector gradually.
	
	public void updateXMomentum()
	{
		//Positive direction is going right.
		//These conditionals push us towards a positive Desired Speed.
		if (ourFacing == Facing.RIGHT)
		{
			if (currentSpeed < desiredSpeed)
			{
				currentSpeed += (acceleration * Time.deltaTime);
			}
			else if (currentSpeed > desiredSpeed)
			{
				currentSpeed -= (deceleration * Time.deltaTime);
			}					
		}
		
		//Remember, negative direction is going left.
		//These conditionals push us towards a negative Desired Speed.
		if (ourFacing == Facing.LEFT)
		{
			if (currentSpeed > desiredSpeed)
			{
				currentSpeed -= (acceleration * Time.deltaTime);
			}
			else if (currentSpeed < desiredSpeed)
			{
				currentSpeed += (deceleration * Time.deltaTime);
			}
		}
		
		//epsilon is .01 currently
		if ( Mathf.Abs(currentSpeed - desiredSpeed) < .01f && desiredSpeed == 0)
		{
			currentSpeed = 0;
		}
		
		//If we push left, desired speed is negative max speed.
		//If we push right, desired speed is positive max speed.
		//If we push neither, desired speed is zero.
		

	}
		
	public void checkActionInput()
	{
		if ((Input.GetKeyDown(KeyCode.Space)))// || touchScreenChug)
		{
			drinkBeer();
		}
	}
		
	public Vector3 checkSwimInput(Vector3 movement)
	{
		//our left and right movement will be the same regardless of
		//swimming or walking.  Just do it.
		//movement = checkLeftRightMovement();
		
		if ( Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow) )
		{
			movement.y = 1;
		}
		else if(Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow) )
		{
			movement.y = -1;
		}
		
		return movement;
	}
	
	public void checkLeftRightMovement()
	{
		//left and right controls:
		//////////////////////////////////////////////////////////////////////////////
		
		/*The pattern for these commands is as such: modify the movement vector,
		 * Change facing,
		 * Start the animation if it's not already playing,
		 * Flag the animation as playing.*/
	
		//Go Left
		if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow) || touchScreenLeft) 
		{ 
			desiredSpeed = maxSpeed * -1;
			ourFacing = Facing.LEFT;

			if (currentAnim != xa.anim.WalkLeft)
					mySprite.Play("runLeft");
			currentAnim = xa.anim.WalkLeft;

		}
		
		//Go Right
		else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow) || touchScreenRight) 
		{
			desiredSpeed = maxSpeed;
			ourFacing = Facing.RIGHT;
			
			if (currentAnim != xa.anim.WalkRight)
				mySprite.Play("runRight");
			currentAnim = xa.anim.WalkRight;		
		}
		
		// If we're not moving either direction, set the x component of the vector to 0.0.
		else { desiredSpeed = 0;}
		
		//NOVEMBER 13, 2013:  stop running when you hit a thing on the side.
		if( (controller.collisionFlags & CollisionFlags.Sides) != 0)
		{
			desiredSpeed = 0;
			currentSpeed = 0;
		}
		
		
		
		/* STANDING ANIMATIONS:  Are we facing a direction, but not pressing the key
		//to move in that direction?  Then we display standing still!  Do not modify
		//movement, otherwise the logic is the same as above.*/
		
		//Standing Left
		if (ourFacing == Facing.LEFT)
		{
			if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow) || touchScreenLeft)
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandLeft)
					mySprite.Play("StandLeft");
				currentAnim = xa.anim.StandLeft;
			}
		}
		
		//Standing Right
		if (ourFacing == Facing.RIGHT)
		{
			if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow) || touchScreenRight)
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandRight)
					mySprite.Play("StandRight");
				currentAnim = xa.anim.StandRight;
			}
		}
		
		return;	
	}
	
	
	public Vector3 checkMovementInput(Vector3 movement)
	{	
		//our left and right movement will be the same regardless of
		//swimming or walking.  Just do 
		//movement = checkLeftRightMovement();
		
		//I've re-written all of the keyboard controls from the original tutorial as they do not make for very smooth
		//playing and can cause some issues with jumping --Jamie O
		
		// keyboard input and results.
		checkLeftRightMovement();
		
		

		/*
		 *JUMPING CONTROLS:
		 *Jumping has three states:  Jumping, falling, and on the ground.
		 *Pressing the jump key when you are on the ground creates vertical acceleration.
		 *Being in the air applies negative acceleration (gravity).
		 *Being on the ground negates negative acceleration.
		 */
			
		if ((controller.collisionFlags & CollisionFlags.Sides) > 0)
		{
			canWallJump = true;
		}
		
		//new code November 13 for Wall Jumping --If we are already jumping, and we are touching a wall,
		//we can wall-jump.
		//If we want to jump off a wall on our right, we have to be travelling right.  We have to
		//push jump and away (left).
		if ( (!canJump && canWallJump) && Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.D) )
		{
			if (momentumDirection == Facing.RIGHT)
			{
				currentSpeed = -maxSpeed;
				playJumpSound();
				movement.y = JUMP_SPEED;
				momentumDirection = Facing.LEFT;
				print ("Wall jump off right wall!");
			}
			
	
		}
		
		//If we want to jump off a wall on our left, we have to be travellng left.  We have to
		//push jump and away (right).
		if ( (!canJump && canWallJump) && Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.A) )
		{
			
			if (momentumDirection == Facing.LEFT)
			{
				currentSpeed = maxSpeed;
				playJumpSound();
				movement.y = JUMP_SPEED;
				momentumDirection = Facing.RIGHT;
				print ("Wall jump off left wall!");
			}
		}
		
		//new Code November 13 for Double Jumping --If we are already jumping, and we can double jump, and we push the button
		if ( (!canJump && canDoubleJump) &&  ( Input.GetKeyDown(KeyCode.W) || Input.GetKeyUp(KeyCode.UpArrow) ) )
		{
			playJumpSound();
			movement.y = JUMP_SPEED;
			canDoubleJump = false;
		}		
		
		//If you have a jump available
		if ((Input.GetKeyDown(KeyCode.W) || Input.GetKeyUp(KeyCode.UpArrow) || touchScreenJump) && canJump)
		{
			playJumpSound();
			movement.y = JUMP_SPEED;
			canJump = false;
		}
		
		if (!controller.isGrounded)
		{
			canJump = false;
		}
				
		if (controller.isGrounded && canJump)
		{
			movement.y = 0;
		}
		else
		{
			//canJump = false;
			movement.y -= GRAVITY * Time.deltaTime;
		}
		
		//NOVEMBER 13, 2013:  stop upward momentum when you hit a thing on your head.
		if( (controller.collisionFlags & CollisionFlags.Above) != 0 && movement.y > 0)
		{
			movement.y = 0;
		}
		

		touchScreenJump = false;
		touchScreenLeft = false;
		touchScreenRight = false;
		touchScreenChug = false;
		
		return movement;
	}
	
	/* updateMovement() takes the movement vector that has been augmented
	 * by the player input, and converts that into a vector that will move
	 * Boh Boy to his new location.  It does check for collisions!
	*/
	public void updateMovement(Vector3 movement)
	{
		movement.x = currentSpeed;
		movement = transform.TransformDirection(movement);
		movement *= MOVE_SPEED; //our movement rate.
		//movement.y -= GRAVITY;
		controller.Move(movement * Time.deltaTime);
	}
	
	
	//Clear the movement vector with this method.  Use this at the start of an update to avoid
	//old data contaminating any movement calculations.
	private void zeroMoveVector()
	{
		movement = Vector3.zero;
	
	}
	
	//Beer managing functions here.
	public int getBeerCount()
	{
		return beerCount;
	}
	public void addBeer()
	{
		playCollectSound();
		beerCount++;
	}
	public void loseBeer()
	{
		beerCount--;
	}
	
	public void drinkBeer()
	{
		if (getBeerCount() > 0)
		{
			loseBeer();
			BAC += BEER_BAC_VALUE;
		}
		updateBACTier();
	}
	
	public void lowerBAC(double dropFactor)
	{
		BAC -= dropFactor;
		if (BAC < 0.0) BAC = 0.0;
		updateBACTier();
	}
	
	public double getBAC()
	{
		return BAC;
	}
	
	public GameData.DrunkennessTier getTier()
	{
		return tier;
	}
	
	public void setTier(GameData.DrunkennessTier newTier)
	{
		tier = newTier;
	}
	
	
	/*
	 * This is the Blood Alcohol Content Tiering Table that I discussed with Matt.
	 * It is based off the table on Wikipedia, and transforms our BAC into
	 * one of eight tiers of drunkenness.  The actual effects can be implemented
	 * elsewhere.  --Jamie O
	 * */
	public void updateBACTier()
	{
		GameData.DrunkennessTier newTier = GameData.DrunkennessTier.TIER_0;
		
		double ourBAC = getBAC();
		
		if (ourBAC <= 0.010)
		{
			newTier = GameData.DrunkennessTier.TIER_0;
		}
		
		if (ourBAC > 0.010 && ourBAC <= 0.029)
		{
			newTier = GameData.DrunkennessTier.TIER_1;
		}
		
		if (ourBAC > 0.029 && ourBAC <= 0.059)
		{
			newTier = GameData.DrunkennessTier.TIER_2;
		}
		
		if (ourBAC > 0.059 && ourBAC <= 0.099)
		{
			newTier = GameData.DrunkennessTier.TIER_3;
		}
		
		if (ourBAC > 0.099 && ourBAC <= 0.19)
		{
			newTier = GameData.DrunkennessTier.TIER_4;
		}
		
		if (ourBAC > 0.19 && ourBAC <= 0.29)
		{
			newTier = GameData.DrunkennessTier.TIER_5;
		}
		
		if (ourBAC > 0.29 && ourBAC <= 0.39)
		{
			newTier = GameData.DrunkennessTier.TIER_6;
		}
		
		if (ourBAC > 0.39 && ourBAC <= 0.50)
		{
			newTier = GameData.DrunkennessTier.TIER_7;
		}
		
		if (ourBAC > .50)
		{
			newTier = GameData.DrunkennessTier.TIER_8;
		}
		
		if (newTier != tier)
		{
			drunkTierDifferent = true;
		}
		
		tier = newTier;
		return;
	}
	
	public void clearTierDifferent()
	{
		drunkTierDifferent = false;
	}
	public bool isTierDifferent()
	{
		return drunkTierDifferent;
	}
	
	public void changeMaxSpeed()
	{
		//if the drunkenness tier is different, change 
		if (!isTierDifferent ())
		{
		}
		
		if (tier == GameData.DrunkennessTier.TIER_0)
		{
			maxSpeed = 1.2f;
		}
		if (tier == GameData.DrunkennessTier.TIER_1)
		{
			maxSpeed = 1.3f;		
		}
		if (tier == GameData.DrunkennessTier.TIER_2)
		{
			maxSpeed = 1.4f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_3)
		{
			maxSpeed = 1.5f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_4)
		{
			maxSpeed = 1.6f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_5)
		{
			maxSpeed = 1.7f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_6)
		{
			maxSpeed = 1.8f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_7)
		{
			maxSpeed = 1.9f;			
		}
		if (tier == GameData.DrunkennessTier.TIER_8)
		{
			maxSpeed = 2.2f;
		}	
	}
	
	
	public void playJumpSound()
	{
		clips[0].Play();
	}
	
	public void playCollectSound()
	{
		clips[1].Play();
	}
	
	public void playHurtSound()
	{
		clips[2].Play();
	}
	
	
	public void pushTSJump()
	{
		if (canJump)
		{
			playJumpSound();
			movement.y = JUMP_SPEED;
			canJump = false;
		}
				
		if (controller.isGrounded && canJump)
		{
			movement.y = 0;
		}
		else
		{
			canJump = false;
			movement.y -= GRAVITY * Time.deltaTime;
		}
	}
	
	public void pushTSLeft()
	{touchScreenLeft = true;}
	public void pushTSRight()
	{touchScreenRight = true;}
	public void pushTSChug()
	{
		drinkBeer();
		//touchScreenChug = true;
	}
	
	
	//This method is called if the enemy collides with a thing.  We want to use it to
	//see if we hit the Boh Boy.
	void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (hit.gameObject.tag == "Enemies") 
		{
			playHurtSound();
			Destroy(hit.gameObject);
		}
	}
	
	void OnTriggerStay(Collider other)
	{
		if (other.gameObject.tag == "Water")
		{
			isSwimming = true;
		}
	}
}
