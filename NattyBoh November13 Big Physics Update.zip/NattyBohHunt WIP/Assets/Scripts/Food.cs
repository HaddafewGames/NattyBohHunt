﻿using UnityEngine;
using System.Collections;

public class Food : MonoBehaviour
{
	public double BAC_reduction;		//I hate that this is public, but it is used
										//in the Unity editor to set the value for each type of food.
	private const int POINTS_VALUE = 50;
	
	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}
	
	//OnTriggerEnter checks to see if the food can has been touched.
	//We really only care if Boh Boy touches the food, so we'll start with a check
	//for that.  Then we'll see if he's got what it takes to pick it up.
	//We'll favor fast returns in our logic and avoid nested if statements.
	
	void OnTriggerEnter(Collider other)
	{
		//If something other than Boh Boy touches the can, return.
		if (other.gameObject.name.Equals("NattyBohBoy"))
		{
		}
		else
		{
			return;
		}
		
		//Now that we are guaranteed a player object, make a pointer to it.
		Player playerPointer = (Player)other.gameObject.GetComponent(typeof(Player));
		
		//Collect the beer if we have room for it.
		if (playerPointer.getBAC() != 0.0)
		{
		playerPointer.lowerBAC(BAC_reduction);
		Destroy (this.gameObject);
			
		//Make a pointer to the world data, and raise our score!
		GameData worldPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
		worldPointer.raiseScore(POINTS_VALUE);
		}
	}
	
	/*void OnTriggerEnter(Collider other)
	{
		//If something other than Boh Boy touches the can, return.
		if (other.gameObject.name.Equals("NattyBohBoy"))
		{
			print ("Collision");
		}
		else
		{
			print ("ErrorCollision");
			return;
		}
		
		//Now that we are guaranteed a player object, make a pointer to it.
		Player playerPointer = (Player)other.gameObject.GetComponent(typeof(Player));
		
		//Collect food if we have a BAC higher than 0.
		if (playerPointer.getBAC() > 0.0)
		{
		playerPointer.lowerBAC(BAC_reduction);
		Destroy (this.gameObject);
		}
	}*/
}
