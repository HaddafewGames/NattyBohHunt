using UnityEngine;
using System.Collections;

/*This code is based on a video by Devin Curry called
"Unity Touch Input Buttons Tutorial" found on Youtube.
*This is demo code and does not do anything for the game.
*/

public class TouchButtonLogic : MonoBehaviour
{
	void Update ()
	{
		
		//If there are no touches, do nothing.
		if(Input.touches.Length <= 0)
		{}
		
		//If there are...
		else
		{
			//Loop through all the touches on screen
			for (int i = 0; i  < Input.touchCount; i++)
			{
				//If the current touch hits the GUI texture...
				if (this.guiTexture.HitTest(Input.GetTouch(i).position))
				{
					if(Input.GetTouch(i).phase == TouchPhase.Began)
					{
						Debug.Log("The Touch has begun on " + this.name);
					}
					if (Input.GetTouch (i).phase == TouchPhase.Ended)
					{
						Debug.Log ("The Touch has ended on " + this.name);
					}
				}
			}
		}
		
	}

}

