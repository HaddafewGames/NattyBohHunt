using UnityEngine;
using System.Collections;

/*This script is a heavily modified version of the one published by Rocket5 Studios as part of
 * their "Make a 2D Game in Unity3d Using Only Free Tools" series.  We have completely rewritten
 * the controls, heavily modified how animations are selected, and are implementing jumping and other
 * motions not used in the original.  Many sections of the code refer to components will will not be using;
 * these will be cleaned up in subsequent edits.
 * 
 * --Jamie O
 *
 **/


// This script is part of the tutorial series "Making a 2D game with Unity3D using only free tools"
// http://www.rocket5studios.com/tutorials/make-a-2d-game-in-unity3d-using-only-free-tools-part-1

public class Player : MonoBehaviour {

	// Shoot objects; these will be deprecated, may not be safe to remove yet.
	private Transform shootParent; //kill this.
	private Renderer shootRenderer; //kill this.
	private OTAnimatingSprite shootSprite; ///kill this.
	
	
	//Movement constants
	private const float MOVE_SPEED = 8.0f;
	private const float GRAVITY = (MOVE_SPEED);
	private const float JUMP_SPEED = MOVE_SPEED * (2.0f/3.0f); 	//Jump speed seems to scale best
																//as a fraction of move speed.
	
	
	//Obsolete movement control flags; these will be deprecated; may not be safe to remove yet.
	private int moveDirX; //kill this.
	private int moveDirY; //kill this.
	
	//The movement vector is very important as it will tell our transform where the player
	//is moving.
	private Vector3 movement;
	private Transform thisTransform;
	
	//Jumping stuff
	private bool grounded = true;
			
	// raycasts -- I'm not really sure how these work or if they will be a part of our final implementation.
	private float rayBlockedDistX = 0.6f;
	private RaycastHit hit;
	
	// layer masks -- I'm not really sure how these work or if they will be a part of our final implementation.	
	private int groundMask = 1 << 8; // layer = Ground
	private int shootMask = 1 << 8 | 1 << 9; // layers = Ground, Ladder
	
	/*Flags having to do with the tutorial game; these will be removed when safe.*/
	private bool dropFromRope = false; //kill this.
	private bool shotBlockedLeft; //kill this.
	private bool shotBlockedRight; //kill this.
	
	private Vector3 spawnPoint; //kill this.
	private Vector3 ladderHitbox;//kill this.
	
	
	/*These control animating state*/
	public OTAnimatingSprite mySprite;
	public xa.anim currentAnim;
	
	
	/*Our way of determining facing is much easier to understand*/
	public enum Facing {LEFT, RIGHT};
	public Facing ourFacing;
	

	
	void Awake() 
	{
		thisTransform = transform;
		movement = new Vector3(0f,0f,0f);
	}
	
	void Start()
    {
		xa.alive = true;

		mySprite = GetComponent<OTAnimatingSprite>();
		ourFacing = Facing.RIGHT;
		spawnPoint = thisTransform.position; // player will respawn at initial starting point
		
    }
	
	/* ============================== CONTROLS ============================== */
	
	
	public void FixedUpdate()
	{
		//physics stuff; nothing needed yet.
		
	}
	
	
	public void Update ()
	{		
		UpdateRaycasts();
		
		
		//I've re-written all of the keyboard controls from the original tutorial as they do not make for very smooth
		//playing and can cause some issues with jumping --Jamie O
		
		// keyboard input and results.
		
		//left and right controls:
		//////////////////////////////////////////////////////////////////////////////
		
		/*The pattern for these commands is as such: modify the movement vector,
		 * Change facing,
		 * Start the animation if it's not already playing,
		 * Flag the animation as playing.*/
		
		//Go Left
		if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) 
		{ 
			movement.x = -1.0f;
			ourFacing = Facing.LEFT;

			if (currentAnim != xa.anim.WalkLeft)
					mySprite.Play("runLeft");
			currentAnim = xa.anim.WalkLeft;

		}
		
		//Go Right
		else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) 
		{
			movement.x = 1.0f; 
			ourFacing = Facing.RIGHT;
			
			if (currentAnim != xa.anim.WalkRight)
				mySprite.Play("runRight");
			currentAnim = xa.anim.WalkRight;		
		}
		
		// If we're not moving either direction, set the x component of the vector to 0.0.
		else { movement.x = 0.0f;}
		
		/* STANDING ANIMATIONS:  Are we facing a direction, but not pressing the key
		//to move in that direction?  Then we display standing still!  Do not modify
		//movement, otherwise the logic is the same as above.*/
		
		//Standing Left
		if (ourFacing == Facing.LEFT)
		{
			if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandLeft)
					mySprite.Play("StandLeft");
				currentAnim = xa.anim.StandLeft;
			}
		}
		
		//Standing Right
		if (ourFacing == Facing.RIGHT)
		{
			if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandRight)
					mySprite.Play("StandRight");
				currentAnim = xa.anim.StandRight;
			}
		}
		
		
		

		//////////////////////////////////////////////////////////////////////////////
		/*UP AND DOWN CONTROLS:
		 * At the moment up just moves us along the Y axis; it does not
		 * apply a limited jump;  Down is for debugging and allows us to move
		 * straight down; this will not be replaced with ducking in the standard gameplay*/
		//up and down controls:
		
		if (Input.GetKey(KeyCode.W))
		{
			movement.y = JUMP_SPEED;
		}
		else if (Input.GetKey (KeyCode.S))
		{ movement.y = -1.0f;}
		
		else {movement.y = 0.0f;}
	
		
		
		movement *= MOVE_SPEED * Time.deltaTime; //our movement rate.
		movement.y -= GRAVITY * Time.deltaTime;
		thisTransform.Translate(movement.x, movement.y, 0f);

		//UpdateMovement(); --I am trying to completely remove this method.  Don't try to understand the madness.
	}
	
	
	//END OF UPDATE() -- TODO:  Chunk Update() into several methods for readability
	/////////////////////////////////////////////////////////////////////////////
	
	//--I am trying to completely remove this method.  Don't try to understand the madnes
	/*UpdateMovement is where we'll have the pleasure of figuring out how to move our person in response to the
	input given to us by the player and the in-game logic.  My current challenge is figuring out WHY THE CHARACTER COLLIDES INTO THE GROUND.
	THIS PREVENTS GOOD JUMPING.*/
	void UpdateMovement() 
	{
		//We'll maintain x movement regardless of whether we are falling or not.
		movement.x = moveDirX;
		
				if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) 
		{ 
			//We'll need to make sure we're not jumping in the middle of another jump...yet
			if (!xa.jumpingUp  && !xa.falling)
			{
				xa.jumpTimer = Time.time + xa.jumpRate;
				xa.jumpingUp = true;
				
			}
		}
		
		
		//If we are jumping up, increase y.
		if (xa.jumpingUp)
		{
			movement.y = 1;
		}
		
		// player is NOT FALLING so move normally
		if(!xa.falling) 
		{
			movement *= Time.deltaTime * MOVE_SPEED;
		}
				
		// Player is FALLING so apply gravity
		if (xa.falling)
		{
			movement.y = -1f;
			movement *= Time.deltaTime * MOVE_SPEED;
		}
		
		//Move our player.
		thisTransform.Translate(movement.x, movement.y, 0f);
	}
	
	/* ============================== RAYCASTS ============================== */
	
	void UpdateRaycasts() 
	{
		// set these to false unless a condition below is met
		xa.blockedRight = false;
		xa.blockedLeft = false;
		shotBlockedLeft = false;
		shotBlockedRight = false;
		
		// is the player is standing on the ground?
		// cast 2 rays, one on each side of the character
		if (Physics.Raycast(new Vector3(thisTransform.position.x-0.3f,thisTransform.position.y,thisTransform.position.z+1f), -Vector3.up, out hit, 0.7f, groundMask) || Physics.Raycast(new Vector3(thisTransform.position.x+0.3f,thisTransform.position.y,thisTransform.position.z+1f), -Vector3.up, out hit, 0.7f, groundMask))
		{	
			xa.falling = false;
			
			// snap the player to the top of a ground tile if she's not on a ladder
			if(!xa.onLadder)
			{
				thisTransform.position = new Vector3(thisTransform.position.x, hit.point.y + xa.playerHitboxY, 0f);
			}
		}
		
		// then maybe she's falling
		else
		{
			if(!xa.onRope && !xa.falling && !xa.onLadder && !xa.jumpingUp) {
				xa.falling = true;
			}
		}
		
		// player is blocked by something on the right
		// cast out 2 rays, one from the head and one from the feet
		if (Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y+0.3f,thisTransform.position.z+1f), Vector3.right, rayBlockedDistX, groundMask) || Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y-0.4f,thisTransform.position.z+1f), Vector3.right, rayBlockedDistX, groundMask))
		{
			xa.blockedRight = true;
		}
		
		// player is blocked by something on the left
		// cast out 2 rays, one from the head and one from the feet
		if (Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y+0.3f,thisTransform.position.z+1f), -Vector3.right, rayBlockedDistX, groundMask) || Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y-0.4f,thisTransform.position.z+1f), -Vector3.right, rayBlockedDistX, groundMask))
		{
			xa.blockedLeft = true;
		}
		
		// is there something blocking our shot to the right?
		if (Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y,thisTransform.position.z+1f), Vector3.right, 1f, shootMask))
		{
			shotBlockedRight = true;
		}
		
		// is there something blocking our shot to the left?
		if (Physics.Raycast(new Vector3(thisTransform.position.x,thisTransform.position.y,thisTransform.position.z+1f), -Vector3.right, 1f, shootMask))
		{
			shotBlockedLeft = true;
		}
		
		// did the shot hit a brick tile to the left?
		if (Physics.Raycast(new Vector3(thisTransform.position.x-1f,thisTransform.position.y,thisTransform.position.z+1f), -Vector3.up, out hit, 0.6f, groundMask))
		{
			if(!shotBlockedLeft && xa.isShoot && xa.facingDir == 1) {
				// breaking bricks will be added in an upcomming tutorial
				/*if (hit.transform.GetComponent<Brick>())
				{
					StartCoroutine(hit.transform.GetComponent<Brick>().PlayBreakAnim());
				}*/
			}
		}
		
		// did the shot hit a brick tile to the right?
		if(Physics.Raycast(new Vector3(thisTransform.position.x+1f,thisTransform.position.y,thisTransform.position.z+1f), -Vector3.up, out hit, 0.6f, groundMask))
		{
			if(!shotBlockedRight && xa.isShoot && xa.facingDir == 2) {
				// breaking bricks will be added in an upcomming tutorial
				/*if (hit.transform.GetComponent<Brick>())
				{
					StartCoroutine(hit.transform.GetComponent<Brick>().PlayBreakAnim());
				}*/
			}
		}
		
		// is the player on the far right edge of the screen?
		if (thisTransform.position.x + xa.playerHitboxX > (Camera.mainCamera.transform.position.x + xa.orthSizeX)) 
		{
			xa.blockedRight = true;
		}
		
		// is the player on the far left edge of the screen?
		if (thisTransform.position.x - xa.playerHitboxX < (Camera.mainCamera.transform.position.x - xa.orthSizeX)) 
		{
			xa.blockedLeft = true;
		}
	}	
	
	/* ============================== SHOOT ====================================================================== */
	
	IEnumerator Shoot()
	{
		xa.shooting = true;
		
		// show the shoot sprite and play the animation
		shootRenderer.enabled = true;
		shootSprite.Play("shoot");
		
		// check facing direction and flip the shoot parent to the correct side
		if(xa.facingDir == 1)
		{
			shootParent.localScale = new Vector3(1,1,1); // left side
		}
		if(xa.facingDir == 2)
		{
			shootParent.localScale = new Vector3(-1,1,1); // right side
		}
		
		yield return new WaitForSeconds(0.4f);
		
		// hide the sprite
		shootRenderer.enabled = false;
		xa.shooting = false;
	}
	
	/* ============================== DEATH AND RESPAWN ====================================================================== */
	
	void RespawnPlayer()
	{
		// respawn the player at her initial start point
		thisTransform.position = spawnPoint;
		xa.alive = true;
	}
	
	/* ============================== TRIGGER EVENTS ====================================================================== */
	
	void OnTriggerEnter(Collider other)
	{
		// did the player collide with a pickup?
		// pickups and scoring will be added in an upcomming tutorial
		/*if (other.gameObject.CompareTag("Pickup"))
		{
			if (other.GetComponent<Pickup>())
			{
				other.GetComponent<Pickup>().PickMeUp();
				xa.sc.Pickup();
			}
		}*/
	}
	
	void OnTriggerStay(Collider other)
	{
		// has the player been crushed by a block?
		// this will be added in an upcomming tutorial
		/*if (other.gameObject.CompareTag("Crusher"))
		{
			if(xa.alive)
			{
				xa.alive = false;
				RespawnPlayer();
				xa.sc.LifeSubtract();
			}
		}*/
		
		// is the player overlapping a ladder?
		if(other.gameObject.CompareTag("Ladder"))
		{
			xa.onLadder = false;
			xa.blockedUp = false;
			xa.blockedDown = false;
			
			ladderHitbox.y = other.transform.localScale.y * 0.5f; // get half the ladders Y height
			
			// is the player overlapping the ladder?
			// if player is landing on top of ladder from a fall, let him pass by
			if ((thisTransform.position.y + xa.playerHitboxY) < ((ladderHitbox.y + 0.1f) + other.transform.position.y))
			{
				xa.onLadder = true;
				xa.falling = false;
			}
			
			// if the player is at the top of the ladder, then snap her to the top
			if ((thisTransform.position.y + xa.playerHitboxY) >= (ladderHitbox.y + other.transform.position.y) && xa.isUp)
			{
				xa.blockedUp = true;
				xa.glx = thisTransform.position;
                xa.glx.y = (ladderHitbox.y + other.transform.position.y) - xa.playerHitboxY;
                thisTransform.position = xa.glx;
			}
			
			// if the player is at the bottom of the ladder, then snap her to the bottom
			if ((thisTransform.position.y - xa.playerHitboxY) <= (-ladderHitbox.y + other.transform.position.y))
			{
				xa.blockedDown = true;
				xa.glx = thisTransform.position;
				xa.glx.y = (-ladderHitbox.y + other.transform.position.y) + xa.playerHitboxY;
                thisTransform.position = xa.glx;
			}
		}
		
		// is the player overlapping a rope?
		if(other.gameObject.CompareTag("Rope"))
		{
			xa.onRope = false;
			
			if(!xa.onRope && !dropFromRope) 
			{
				// snap player to center of the rope
				if (thisTransform.position.y < (other.transform.position.y + 0.2f) && thisTransform.position.y > (other.transform.position.y - 0.2f))
                {
					xa.onRope = true;
					xa.falling = false;
					xa.glx = thisTransform.position;
                    xa.glx.y = other.transform.position.y;
                    thisTransform.position = xa.glx;
                }
			}
		}
	}
	
	void OnTriggerExit(Collider other)
	{
		// did the player exit a rope trigger?
		if (other.gameObject.CompareTag("Rope"))
		{
			xa.onRope = false;
			dropFromRope = false;
		}
		
		// did the player exit a ladder trigger?
		if (other.gameObject.CompareTag("Ladder")) 
		{
			xa.onLadder = false;
		}
	}
}
