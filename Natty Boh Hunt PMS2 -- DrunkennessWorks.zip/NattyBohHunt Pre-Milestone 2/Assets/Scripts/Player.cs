using UnityEngine;
using System.Collections;

/*This script is a heavily modified version of the one published by Rocket5 Studios as part of
 * their "Make a 2D Game in Unity3d Using Only Free Tools" series.  We have completely rewritten
 * the controls, heavily modified how animations are selected, and are implementing jumping and other
 * motions not used in the original.  Many sections of the code refer to components will will not be using;
 * these will be cleaned up in subsequent edits.
 * 
 * --Jamie O
 *
 **/


// This script is part of the tutorial series "Making a 2D game with Unity3D using only free tools"
// http://www.rocket5studios.com/tutorials/make-a-2d-game-in-unity3d-using-only-free-tools-part-1

[RequireComponent(typeof (CharacterController))]

public class Player : MonoBehaviour
{
	
	
	//TODO:  Check out these constants and make sure that the ratios are perfect.  Jump
	//speed is very, very hard to nail down so that the height vs. fall speed is good.
	
	//Movement constants
	private const float MOVE_SPEED = 8.0f;
	private const float GRAVITY = (MOVE_SPEED) /*(2.0f/3.0f) */;
	private const float JUMP_SPEED = MOVE_SPEED * (50.0f/100.0f); 	//Jump speed seems to scale best
																	//as a fraction of move speed.
	
	//The movement vector is very important as it will tell the CharacterController where to move.
	private Vector3 movement;
	private CharacterController controller;
	
	//Variabes used to manage jumping.
	private bool canJump;
	private bool canDoubleJump;
			
	//Variables for counting beer
	private GameData.DrunkennessTier tier;
	private int beerCount;
	private double BAC;
	private const double BEER_BAC_VALUE = 0.018;		//This value was taken from http://bloodalcoholcalculator.org/
														//as one light beer at its highest blood concentration.
	private bool drunkTierDifferent;
	
	//These control animating state*/
	public OTAnimatingSprite mySprite;
	public xa.anim currentAnim;
	
	
	//sound clips that originate from the Boh Boy:
	AudioSource[] clips;
		
	
	//We define a way to determine our facing in easily-understood language*/
	public enum Facing {LEFT, RIGHT};
	public Facing ourFacing;
		
	void Awake() 
	{
		movement = new Vector3(0f,0f,0f);
		controller = (CharacterController) GetComponent(typeof(CharacterController));
		beerCount = 0;
		BAC = 0;
		drunkTierDifferent = false;
		
	}
	
	void Start()
    {
		xa.alive = true;
		mySprite = GetComponent<OTAnimatingSprite>();
		ourFacing = Facing.RIGHT;						//Games just tend to start with the hero facing right.
														//This is a convention and has no real bearing in gameplay.
		
		//Load all of the sound clips for the Boh Boy into the clips container.
		int numberOfClips = GetComponents(typeof(AudioSource)).Length;
		clips = new AudioSource[numberOfClips];
		
		for (int i = 0; i < numberOfClips; i++)
		{
			clips[i]= (AudioSource)GetComponents(typeof(AudioSource))[i];
		}		
    }
	

	public void FixedUpdate()
	{
		//physics stuff; nothing needed yet.
		
	}
	
	public void Update ()
	{	
		if (controller.isGrounded) canJump = true;
		if (controller.isGrounded) canDoubleJump = true;
		
		
		movement = checkMovementInput(movement);	//Update the movement vector by looking for input from the keyboard.
		checkActionInput();
		updateMovement(movement);  			//Move Boh Boy according to the input vs. collision/physics.
	}
	
		
	public void checkActionInput()
	{
		if (Input.GetKeyDown(KeyCode.Space))
		{
			drinkBeer();
		}
	}
	public Vector3 checkMovementInput(Vector3 movement)
	{
		//I've re-written all of the keyboard controls from the original tutorial as they do not make for very smooth
		//playing and can cause some issues with jumping --Jamie O
		
		// keyboard input and results.
		
		//left and right controls:
		//////////////////////////////////////////////////////////////////////////////
		
		/*The pattern for these commands is as such: modify the movement vector,
		 * Change facing,
		 * Start the animation if it's not already playing,
		 * Flag the animation as playing.*/
		

		

		
		//Go Left
		if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) 
		{ 
			movement.x = -1;
			ourFacing = Facing.LEFT;

			if (currentAnim != xa.anim.WalkLeft)
					mySprite.Play("runLeft");
			currentAnim = xa.anim.WalkLeft;

		}
		
		//Go Right
		else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) 
		{
			movement.x = 1; 
			ourFacing = Facing.RIGHT;
			
			if (currentAnim != xa.anim.WalkRight)
				mySprite.Play("runRight");
			currentAnim = xa.anim.WalkRight;		
		}
		
		// If we're not moving either direction, set the x component of the vector to 0.0.
		else { movement.x = 0.0f;}
		
		/* STANDING ANIMATIONS:  Are we facing a direction, but not pressing the key
		//to move in that direction?  Then we display standing still!  Do not modify
		//movement, otherwise the logic is the same as above.*/
		
		//Standing Left
		if (ourFacing == Facing.LEFT)
		{
			if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandLeft)
					mySprite.Play("StandLeft");
				currentAnim = xa.anim.StandLeft;
			}
		}
		
		//Standing Right
		if (ourFacing == Facing.RIGHT)
		{
			if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
			{
			}
			else
			{
				if (currentAnim != xa.anim.StandRight)
					mySprite.Play("StandRight");
				currentAnim = xa.anim.StandRight;
			}
		}
		

		/*
		 *JUMPING CONTROLS:
		 *Jumping has three states:  Jumping, falling, and on the ground.
		 *Pressing the jump key when you are on the ground creates vertical acceleration.
		 *Being in the air applies negative acceleration (gravity).
		 *Being on the ground negates negative acceleration.
		 */
		
		//If you have a jump available
		if ((Input.GetKeyDown(KeyCode.W) || Input.GetKeyUp(KeyCode.UpArrow)) && canJump)
		{
			playJumpSound();
			movement.y = JUMP_SPEED;
			canJump = false;
		}
				
		if (controller.isGrounded)
		{
			movement.y = 0;
		}
		else
		{
			canJump = false;
			movement.y -= GRAVITY * Time.deltaTime;
		}
		
		/*else if (Input.GetKey (KeyCode.S))
		{ movement.y = -1.0f;}
		
		else {movement.y = 0.0f;}*/
		
		return movement;
	}
	
	/* updateMovement() takes the movement vector that has been augmented
	 * by the player input, and converts that into a vector that will move
	 * Boh Boy to his new location.  It does check for collisions!
	*/
	public void updateMovement(Vector3 movement)
	{
		movement = transform.TransformDirection(movement);
		movement *= MOVE_SPEED; //our movement rate.
		//movement.y -= GRAVITY;
		controller.Move(movement * Time.deltaTime);
	}
	
	
	//Clear the movment vector with this method.  Use this at the start of an update to avoid
	//old data contaminating any movement calculations.
	private void zeroMoveVector()
	{
		movement = Vector3.zero;
	
	}
	
	//Beer managing functions here.
	public int getBeerCount()
	{
		return beerCount;
	}
	public void addBeer()
	{
		playCollectSound();
		beerCount++;
	}
	public void loseBeer()
	{
		beerCount--;
	}
	
	public void drinkBeer()
	{
		if (getBeerCount() > 0)
		{
			loseBeer();
			BAC += BEER_BAC_VALUE;
		}
		updateBACTier();
	}
	
	public void lowerBAC(double dropFactor)
	{
		BAC -= dropFactor;
		if (BAC < 0.0) BAC = 0.0;
		updateBACTier();
	}
	
	public double getBAC()
	{
		return BAC;
	}
	
	public GameData.DrunkennessTier getTier()
	{
		return tier;
	}
	
	public void setTier(GameData.DrunkennessTier newTier)
	{
		tier = newTier;
	}
	
	
	/*
	 * This is the Blood Alcohol Content Tiering Table that I discussed with Matt.
	 * It is based off the table on Wikipedia, and transforms our BAC into
	 * one of eight tiers of drunkenness.  The actual effects can be implemented
	 * elsewhere.  --Jamie O
	 * */
	public void updateBACTier()
	{
		GameData.DrunkennessTier newTier = GameData.DrunkennessTier.TIER_0;
		
		double ourBAC = getBAC();
		
		if (ourBAC <= 0.010)
		{
			newTier = GameData.DrunkennessTier.TIER_0;
		}
		
		if (ourBAC > 0.010 && ourBAC <= 0.029)
		{
			newTier = GameData.DrunkennessTier.TIER_1;
		}
		
		if (ourBAC > 0.029 && ourBAC <= 0.059)
		{
			newTier = GameData.DrunkennessTier.TIER_2;
		}
		
		if (ourBAC > 0.059 && ourBAC <= 0.099)
		{
			newTier = GameData.DrunkennessTier.TIER_3;
		}
		
		if (ourBAC > 0.099 && ourBAC <= 0.19)
		{
			newTier = GameData.DrunkennessTier.TIER_4;
		}
		
		if (ourBAC > 0.19 && ourBAC <= 0.29)
		{
			newTier = GameData.DrunkennessTier.TIER_5;
		}
		
		if (ourBAC > 0.29 && ourBAC <= 0.39)
		{
			newTier = GameData.DrunkennessTier.TIER_6;
		}
		
		if (ourBAC > 0.39 && ourBAC <= 0.50)
		{
			newTier = GameData.DrunkennessTier.TIER_7;
		}
		
		if (ourBAC > .50)
		{
			newTier = GameData.DrunkennessTier.TIER_8;
		}
		
		if (newTier != tier)
		{
			drunkTierDifferent = true;
		}
		
		tier = newTier;
		return;
	}
	
	public void clearTierDifferent()
	{
		drunkTierDifferent = false;
	}
	public bool isTierDifferent()
	{
		return drunkTierDifferent;
	}
	
	
	
	public void playJumpSound()
	{
		clips[0].Play();
	}
	
	public void playCollectSound()
	{
		clips[1].Play();
	}
	
	public void playHurtSound()
	{
		clips[2].Play();
	}
	
		//This method is called if the enemy collides with a thing.  We want to use it to
	//see if we hit the Boh Boy.
	void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (hit.gameObject.tag == "Enemies") 
		{
			playHurtSound();
			Destroy(hit.gameObject);
		}
	}
}
