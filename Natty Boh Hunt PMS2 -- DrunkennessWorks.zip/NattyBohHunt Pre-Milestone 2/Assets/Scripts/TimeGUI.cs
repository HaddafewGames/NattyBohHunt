﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(GUIText))]

/*
 * The TimeGUI class represents the Scoreboard that runs in the
 * upper center portion of the screen.  It tells us our time remaining.
 * It is independent of the other GUI elements for
 * placement purposes. --Jamie O
 * */

public class TimeGUI : MonoBehaviour 
{
	GameData worldPointer;

	// Use this for initialization
	void Start ()
	{
		//Get a pointer to the Game Data, where the score is held.
		worldPointer = (GameData)GameObject.Find("GAME DATA").GetComponent(typeof(GameData));
	
	}
	
	// Update is called once per frame
	void Update ()
	{
		
		//People may wonder why minutesRemaining is an int and secondsRemaining is a string.
		//Ints are smaller and use less memeory.  But, in order to properly display a clock,
		//in a position like 3:01, we have to be able to write in a zero
		int timeRemaining = (int)worldPointer.getTimer();
		int minutesRemaining = timeRemaining / 60;
		int secondsRemaining = (timeRemaining - (minutesRemaining * 60));
		
		string outputText = "Time:  " + minutesRemaining + ":";
		if (secondsRemaining < 10) { outputText += "0";}
		outputText += secondsRemaining;
		
		this.guiText.text= outputText;
		
	}
}

