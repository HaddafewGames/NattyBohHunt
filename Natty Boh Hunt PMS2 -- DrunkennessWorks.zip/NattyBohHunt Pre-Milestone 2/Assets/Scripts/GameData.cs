﻿using UnityEngine;
using System.Collections;


//Global data can be stored in this class.
public class GameData : MonoBehaviour
{
	public enum DrunkennessTier {TIER_0, TIER_1, TIER_2, TIER_3, TIER_4, TIER_5,
		TIER_6, TIER_7, TIER_8};
	
	private int score;
	private double gameTime;
	
	//This refers to the Boh Boy and allows us to communicate with him.
	private Player playerPointer;
	
	//This refers to the Main Camera and allows us to communicate with it.
	private Camera cameraPointer;
	
	//Our drunkenness tier must be translated into commands to send to the camera and the Boh Boy.
	private DrunkennessTier ourDrinkLevel;
	private Vector3 rotateTo;
	private Vector3 originalZPosition;
	
	private Vector3 clock45;
	private Quaternion counterClock45;
	
	private const float EPSILON = .01f;
	private bool tiltClockwise;
	private bool tiltRecently = false;
	
	
	//Quaternions for set angles for screen rotations.
	Quaternion tier1 = Quaternion.Euler(0,0, 6);
	Quaternion tier1Minus = Quaternion.Euler(0,0,-6);
	
	Quaternion tier2 = Quaternion.Euler(0,0, 12);
	Quaternion tier2Minus = Quaternion.Euler(0,0,-12);
	
	Quaternion tier3 = Quaternion.Euler(0,0, 18);
	Quaternion tier3Minus = Quaternion.Euler(0,0,-18);
	
	Quaternion tier4 = Quaternion.Euler(0,0, 24);
	Quaternion tier4Minus = Quaternion.Euler(0,0,-24);
	
	Quaternion tier5 = Quaternion.Euler(0,0, 30);
	Quaternion tier5Minus = Quaternion.Euler(0,0,-30);
	
	Quaternion tier6 = Quaternion.Euler(0,0, 36);
	Quaternion tier6Minus = Quaternion.Euler(0,0,-36);
	
	Quaternion tier7 = Quaternion.Euler(0,0, 42);
	Quaternion tier7Minus = Quaternion.Euler(0,0,-42);
	
	Quaternion tier8 = Quaternion.Euler(0,0, 45);
	Quaternion tier8Minus = Quaternion.Euler(0,0,-45);
	
	
	
	
	
	// Use this for initialization
	void Start ()
	{
		resetScore();
		gameTime = 300;
		
		tiltClockwise = true;
		
		playerPointer = (Player)GameObject.Find("NattyBohBoy").GetComponent(typeof(Player)); //I hate this cast, but it's necessary.
		cameraPointer = (Camera)GameObject.Find("Main Camera").GetComponent(typeof(Camera));
		rotateTo = Vector3.zero;
		originalZPosition = cameraPointer.transform.position;
		
		clock45 = new Vector3(0, 0, 45);
	}
	
	// Update is called once per frame
	void Update ()
	{
		//update the clock.
		clockTick();
		checkDrinkLevel(playerPointer.getTier());
	}
	
	
	//This is in-progress and is responsible for rotating the game camera when we are drunk.
	//My current thinking is that we should use LERP to have the game move the camera for us.
	//We'll need tests to see-saw:
	//Have we reached the left boundary? if so, go right
	//Have we reached the right boundary? if so, go left.
	void checkDrinkLevel(DrunkennessTier ourDrinkLevel)
	{
		Quaternion spinLevel = Quaternion.identity;
		
		//This lookup table assigns the proper Quaternion
		//for us to rotate towards.
		
		//Zero is a special case.
		if (ourDrinkLevel == DrunkennessTier.TIER_0)
		{
			spinCamera (Quaternion.identity);
			return;
		}
		
		if (ourDrinkLevel == DrunkennessTier.TIER_1)
		{
			spinLevel = tier1;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_2)
		{
			spinLevel = tier2;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_3)
		{
			spinLevel = tier3;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_4)
		{
			spinLevel = tier4;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_5)
		{
			spinLevel = tier5;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_6)
		{
			spinLevel = tier6;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_7)
		{
			spinLevel = tier7;
		}
		if (ourDrinkLevel == DrunkennessTier.TIER_8)
		{
			spinLevel = tier8;
		}
		
		
		spinCamera(spinLevel);
		checkSpin (spinLevel);
		
	}
	
	
	
	/*
	 * Given a Quaternion to represent a z-axis rotation, this method rotates the camer
	 * towards it using Lerp.  This is called by checkDrinkLevel()
	 */
	private void spinCamera(Quaternion spinRotation)
	{
		if (tiltClockwise == true)
		{
			cameraPointer.transform.rotation = Quaternion.Lerp(cameraPointer.transform.rotation, spinRotation, Time.deltaTime * .40f);
		}
		else
		{
			cameraPointer.transform.rotation = Quaternion.Lerp(cameraPointer.transform.rotation, Quaternion.Inverse(spinRotation), Time.deltaTime * .40f);			
		}
	}
	
	
	/**
	 * Improve on this later.  The general logic should be:
	 * If we should spin clockwise, spin clockwise.
	 * If we should spin counter-clockwise, spin counter-clockwise.
	 * Check to see if we should change our spin direction.
	 * If so, change our spin direction.
	 * */
	private void checkSpin(Quaternion spinRotation)
	{
		//We will need to invert the rotation if we are going counter-clockwise
		if (tiltClockwise == false)
			spinRotation = Quaternion.Inverse(spinRotation);
		
		float delta = (cameraPointer.transform.eulerAngles.z - spinRotation.eulerAngles.z);
		
		print (delta);
		
		if ( Mathf.Abs(delta) > EPSILON)
		{
			tiltRecently = false;
		}
		
		
		//if the difference is within tolerance for a change, continue, else leave the method.
		if ( Mathf.Abs(delta) < EPSILON  )
		{
		}
		else return;
		
		//If we've tilted recently, leave the method.
		if (tiltRecently == false)
		{
		}
		else return;
		
		//Toggle the tilt and then immediately leave the method, so there is no fast-switching.
		if (tiltClockwise == false)
		{
			//print ("Switch tilt to clockwise!");
			tiltClockwise = true;
			tiltRecently = true;
			return;
		}
			
		if (tiltClockwise == true)
		{
			print ("Switch tilt to counter-clockwise!");
			tiltClockwise = false;
			tiltRecently = true;
			return;
		}
	}
	
	
	
	//Functions for manipulating the game clock
	public double getTimer() {return gameTime;}
	
	//see if the player is out of time.
	public bool isTimeOut()
	{
		if (gameTime <= 0)
			return true;
		return false;
	}
	
	//This chunk of code is for running the game clock.
	public void clockTick()
	{
		gameTime -= Time.deltaTime;
		if (isTimeOut())
		{
			Application.LoadLevel(2);
		}
		
	}
		
	//Functions for manipulating the score
	public int getScore() {return score;}
	public void resetScore() {score = 0;}
	public void raiseScore(int raise) { score += raise;}
}
