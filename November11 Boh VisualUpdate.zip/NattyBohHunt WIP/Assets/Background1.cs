﻿using UnityEngine;
using System.Collections;

public class Background1 : MonoBehaviour {

	// Use this for initialization
	void Start ()
	{
		Transform thisobject = (Transform)this.gameObject.GetComponent(typeof(Transform));
		Vector3 backOne = new Vector3(0,0,1);
		thisobject.Translate(backOne);
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
