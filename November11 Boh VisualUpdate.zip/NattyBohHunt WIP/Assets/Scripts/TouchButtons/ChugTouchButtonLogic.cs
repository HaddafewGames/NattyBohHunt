using UnityEngine;
using System.Collections;


[RequireComponent(typeof(GUITexture))]
//Code based on examples in the Unity documentation.
public class ChugTouchButtonLogic : MonoBehaviour
{

	
	void Update()
	{
		GUITexture thisHitBox = (GUITexture)gameObject.GetComponent(typeof(GUITexture));
		
		Player playerPointer = (Player)GameObject.Find("NattyBohBoy").GetComponent(typeof(Player)); //I hate this cast, but it's necessary.
  
		
		foreach (Touch touch in Input.touches)
		{
			if(touch.phase == TouchPhase.Began)
			{
				if(thisHitBox.HitTest(touch.position))
				{
					playerPointer.pushTSChug();
				}					
				
			}
			
				
		}
	}
}
